import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/contexts/AuthContext";
import Layout from "@/components/Layout";
import Index from "./pages/Index";
import Doctors from "./pages/Doctors";
import SignIn from "./pages/SignIn";
import SignUp from "./pages/SignUp";
import PlaceholderPage from "@/components/PlaceholderPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
    >
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Layout>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/doctors" element={<Doctors />} />
                <Route path="/signin" element={<SignIn />} />
                <Route path="/signup" element={<SignUp />} />
                <Route
                  path="/appointments"
                  element={
                    <PlaceholderPage
                      title="Appointment Scheduling"
                      description="Book and manage your medical appointments with ease"
                    />
                  }
                />
                <Route
                  path="/messages"
                  element={
                    <PlaceholderPage
                      title="Messages"
                      description="Chat with your healthcare providers"
                    />
                  }
                />
                <Route
                  path="/video"
                  element={
                    <PlaceholderPage
                      title="Video Consultations"
                      description="Connect with doctors through secure video calls"
                    />
                  }
                />
                <Route
                  path="/symptoms"
                  element={
                    <PlaceholderPage
                      title="Symptom Checker"
                      description="Get preliminary guidance based on your symptoms"
                    />
                  }
                />
                <Route
                  path="/settings"
                  element={
                    <PlaceholderPage
                      title="Settings"
                      description="Manage your account and preferences"
                    />
                  }
                />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Layout>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
