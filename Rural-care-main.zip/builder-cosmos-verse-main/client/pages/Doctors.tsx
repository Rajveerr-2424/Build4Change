import { useState } from "react";
import {
  Search,
  Filter,
  Star,
  MapPin,
  Calendar,
  Video,
  Phone,
  Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const doctors = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    specialty: "Family Medicine",
    rating: 4.9,
    reviewCount: 127,
    location: "Rural Health Center",
    distance: "2.3 miles",
    experience: "15 years",
    languages: ["English", "Spanish"],
    availability: ["Today", "Tomorrow"],
    consultationTypes: ["Video Call", "Phone Call"],
    bio: "Dr. Johnson specializes in comprehensive family care with a focus on rural health needs. She has been serving the community for over 15 years.",
    education: "MD from University of Medicine",
    nextAvailable: "Today 2:30 PM",
    avatar: "/placeholder.svg",
    isOnline: true,
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    specialty: "Cardiology",
    rating: 4.8,
    reviewCount: 89,
    location: "Heart Specialist Clinic",
    distance: "5.1 miles",
    experience: "12 years",
    languages: ["English", "Chinese"],
    availability: ["Tomorrow", "Dec 28"],
    consultationTypes: ["Video Call", "Phone Call"],
    bio: "Cardiologist with expertise in rural healthcare and telemedicine. Specializes in heart disease prevention and management.",
    education: "MD, Cardiology Fellowship",
    nextAvailable: "Tomorrow 10:00 AM",
    avatar: "/placeholder.svg",
    isOnline: false,
  },
  {
    id: 3,
    name: "Dr. Emily Rodriguez",
    specialty: "Dermatology",
    rating: 4.7,
    reviewCount: 156,
    location: "Skin Care Center",
    distance: "8.2 miles",
    experience: "10 years",
    languages: ["English", "Spanish"],
    availability: ["Dec 28", "Dec 29"],
    consultationTypes: ["Video Call"],
    bio: "Dermatologist offering comprehensive skin care through telemedicine. Expert in treating common skin conditions remotely.",
    education: "MD, Dermatology Residency",
    nextAvailable: "Dec 28 3:15 PM",
    avatar: "/placeholder.svg",
    isOnline: true,
  },
  {
    id: 4,
    name: "Dr. James Wilson",
    specialty: "Internal Medicine",
    rating: 4.6,
    reviewCount: 203,
    location: "Community Health Center",
    distance: "3.7 miles",
    experience: "18 years",
    languages: ["English"],
    availability: ["Dec 29", "Dec 30"],
    consultationTypes: ["Video Call", "Phone Call"],
    bio: "Internal medicine physician with extensive experience in chronic disease management and preventive care.",
    education: "MD, Internal Medicine",
    nextAvailable: "Dec 29 11:00 AM",
    avatar: "/placeholder.svg",
    isOnline: false,
  },
  {
    id: 5,
    name: "Dr. Lisa Thompson",
    specialty: "Pediatrics",
    rating: 4.9,
    reviewCount: 94,
    location: "Children's Health Clinic",
    distance: "4.5 miles",
    experience: "8 years",
    languages: ["English"],
    availability: ["Today", "Tomorrow"],
    consultationTypes: ["Video Call"],
    bio: "Pediatrician specializing in remote consultations for children's health. Expert in developmental care and common pediatric conditions.",
    education: "MD, Pediatrics Residency",
    nextAvailable: "Today 4:00 PM",
    avatar: "/placeholder.svg",
    isOnline: true,
  },
  {
    id: 6,
    name: "Dr. Robert Kim",
    specialty: "Mental Health",
    rating: 4.8,
    reviewCount: 76,
    location: "Wellness Center",
    distance: "6.3 miles",
    experience: "14 years",
    languages: ["English", "Korean"],
    availability: ["Tomorrow", "Dec 28"],
    consultationTypes: ["Video Call", "Phone Call"],
    bio: "Mental health professional providing therapy and counseling services through secure telemedicine platforms.",
    education: "MD, Psychiatry Residency",
    nextAvailable: "Tomorrow 1:00 PM",
    avatar: "/placeholder.svg",
    isOnline: true,
  },
];

const specialties = [
  "All Specialties",
  "Family Medicine",
  "Cardiology",
  "Dermatology",
  "Internal Medicine",
  "Pediatrics",
  "Mental Health",
];

const availabilityOptions = [
  "Any Time",
  "Today",
  "Tomorrow",
  "This Week",
  "Next Week",
];

export default function Doctors() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSpecialty, setSelectedSpecialty] = useState("All Specialties");
  const [selectedAvailability, setSelectedAvailability] = useState("Any Time");
  const [selectedDoctor, setSelectedDoctor] = useState<
    (typeof doctors)[0] | null
  >(null);

  const filteredDoctors = doctors.filter((doctor) => {
    const matchesSearch =
      doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialty =
      selectedSpecialty === "All Specialties" ||
      doctor.specialty === selectedSpecialty;
    const matchesAvailability =
      selectedAvailability === "Any Time" ||
      doctor.availability.includes(selectedAvailability);

    return matchesSearch && matchesSpecialty && matchesAvailability;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Find a Doctor</h1>
        <p className="text-muted-foreground mt-1">
          Connect with healthcare professionals in your area
        </p>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search doctors by name or specialty..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select
              value={selectedSpecialty}
              onValueChange={setSelectedSpecialty}
            >
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Specialty" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map((specialty) => (
                  <SelectItem key={specialty} value={specialty}>
                    {specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={selectedAvailability}
              onValueChange={setSelectedAvailability}
            >
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Availability" />
              </SelectTrigger>
              <SelectContent>
                {availabilityOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Found {filteredDoctors.length} doctor
          {filteredDoctors.length !== 1 ? "s" : ""}
        </p>
      </div>

      {/* Doctor Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredDoctors.map((doctor) => (
          <Card key={doctor.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start space-x-4">
                <div className="relative">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={doctor.avatar} />
                    <AvatarFallback>
                      {doctor.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  {doctor.isOnline && (
                    <div className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full bg-green-500 border-2 border-background"></div>
                  )}
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg">{doctor.name}</CardTitle>
                  <CardDescription className="text-sm">
                    {doctor.specialty}
                  </CardDescription>
                  <div className="flex items-center space-x-1 mt-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{doctor.rating}</span>
                    <span className="text-sm text-muted-foreground">
                      ({doctor.reviewCount})
                    </span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>
                    {doctor.location} • {doctor.distance}
                  </span>
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>Next available: {doctor.nextAvailable}</span>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Consultation Types:</p>
                <div className="flex flex-wrap gap-1">
                  {doctor.consultationTypes.map((type) => (
                    <Badge key={type} variant="secondary" className="text-xs">
                      {type === "Video Call" && (
                        <Video className="h-3 w-3 mr-1" />
                      )}
                      {type === "Phone Call" && (
                        <Phone className="h-3 w-3 mr-1" />
                      )}
                      {type}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setSelectedDoctor(doctor)}
                    >
                      View Profile
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle className="flex items-center space-x-3">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={doctor.avatar} />
                          <AvatarFallback>
                            {doctor.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold">{doctor.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {doctor.specialty}
                          </p>
                        </div>
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">About</h4>
                        <p className="text-sm text-muted-foreground">
                          {doctor.bio}
                        </p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Education</h4>
                        <p className="text-sm text-muted-foreground">
                          {doctor.education}
                        </p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Languages</h4>
                        <div className="flex flex-wrap gap-1">
                          {doctor.languages.map((lang) => (
                            <Badge
                              key={lang}
                              variant="outline"
                              className="text-xs"
                            >
                              {lang}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
                <Button size="sm" className="flex-1">
                  <Calendar className="h-4 w-4 mr-2" />
                  Book Now
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredDoctors.length === 0 && (
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground">
              No doctors found matching your criteria. Try adjusting your search
              or filters.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
