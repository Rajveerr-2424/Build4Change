import {
  Calendar,
  Clock,
  MessageSquare,
  Activity,
  Heart,
  Plus,
  ArrowRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Link } from "react-router-dom";

export default function Index() {
  const upcomingAppointments = [
    {
      id: 1,
      doctor: "Dr. Sarah Johnson",
      specialty: "Family Medicine",
      date: "Today",
      time: "2:30 PM",
      type: "Video Call",
      avatar: "/placeholder.svg",
    },
    {
      id: 2,
      doctor: "Dr. Michael Chen",
      specialty: "Cardiology",
      date: "Tomorrow",
      time: "10:00 AM",
      type: "Phone Call",
      avatar: "/placeholder.svg",
    },
    {
      id: 3,
      doctor: "Dr. Emily Rodriguez",
      specialty: "Dermatology",
      date: "Dec 28",
      time: "3:15 PM",
      type: "Video Call",
      avatar: "/placeholder.svg",
    },
  ];

  const recentMessages = [
    {
      id: 1,
      doctor: "Dr. Sarah Johnson",
      message:
        "Your test results look good. Please continue with the current medication.",
      time: "2 hours ago",
      unread: true,
    },
    {
      id: 2,
      doctor: "Dr. Michael Chen",
      message: "Remember to take your blood pressure medication daily.",
      time: "1 day ago",
      unread: false,
    },
    {
      id: 3,
      doctor: "Dr. Emily Rodriguez",
      message: "The skin condition is improving. See you next week.",
      time: "3 days ago",
      unread: false,
    },
  ];

  const healthMetrics = [
    {
      label: "Blood Pressure",
      value: "120/80",
      status: "Normal",
      change: "+2",
      color: "text-success",
    },
    {
      label: "Heart Rate",
      value: "72 bpm",
      status: "Normal",
      change: "-1",
      color: "text-success",
    },
    {
      label: "Weight",
      value: "165 lbs",
      status: "Stable",
      change: "-0.5",
      color: "text-success",
    },
    {
      label: "Blood Sugar",
      value: "95 mg/dL",
      status: "Normal",
      change: "+3",
      color: "text-success",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Welcome back, John
          </h1>
          <p className="text-muted-foreground mt-1">
            Here's your health overview for today
          </p>
        </div>
        <Button asChild>
          <Link to="/doctors">
            <Plus className="mr-2 h-4 w-4" />
            Book Appointment
          </Link>
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Next Appointment
            </CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Today</div>
            <p className="text-xs text-muted-foreground">
              2:30 PM with Dr. Johnson
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Unread Messages
            </CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1</div>
            <p className="text-xs text-muted-foreground">From Dr. Johnson</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Health Score</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
            <p className="text-xs text-muted-foreground">Excellent</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Active Treatments
            </CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Ongoing care plans</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Upcoming Appointments */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Upcoming Appointments</CardTitle>
              <CardDescription>Your scheduled consultations</CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/appointments">
                View All
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {upcomingAppointments.map((appointment) => (
              <div key={appointment.id} className="flex items-center space-x-4">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={appointment.avatar} />
                  <AvatarFallback>
                    {appointment.doctor
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium leading-none">
                    {appointment.doctor}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {appointment.specialty}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{appointment.date}</p>
                  <p className="text-sm text-muted-foreground">
                    {appointment.time}
                  </p>
                </div>
                <Badge
                  variant={
                    appointment.type === "Video Call" ? "default" : "secondary"
                  }
                >
                  {appointment.type}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Messages */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Messages</CardTitle>
              <CardDescription>
                Latest communications from your doctors
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/messages">
                View All
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentMessages.map((message) => (
              <div key={message.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium">{message.doctor}</p>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-muted-foreground">
                      {message.time}
                    </span>
                    {message.unread && (
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                    )}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {message.message}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Health Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Health Overview</CardTitle>
          <CardDescription>
            Your latest vital signs and health metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {healthMetrics.map((metric, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{metric.label}</span>
                  <Badge variant="outline" className={metric.color}>
                    {metric.status}
                  </Badge>
                </div>
                <div className="text-2xl font-bold">{metric.value}</div>
                <div className="flex items-center space-x-2">
                  <span className={`text-xs ${metric.color}`}>
                    {metric.change > 0 ? "+" : ""}
                    {metric.change} from last reading
                  </span>
                </div>
                <Progress value={85} className="h-1" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks to manage your health</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Button
              variant="outline"
              className="h-20 flex-col space-y-2"
              asChild
            >
              <Link to="/symptoms">
                <Activity className="h-6 w-6" />
                <span>Check Symptoms</span>
              </Link>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex-col space-y-2"
              asChild
            >
              <Link to="/doctors">
                <Calendar className="h-6 w-6" />
                <span>Book Appointment</span>
              </Link>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex-col space-y-2"
              asChild
            >
              <Link to="/video">
                <Clock className="h-6 w-6" />
                <span>Join Video Call</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
